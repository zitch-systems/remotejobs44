# CLAUDE.md — RemoteJobs44 "Deep Ocean" web → Next.js implementation guide

> This file is for **Claude Code**. It tells you how to turn the HTML design references in
> this folder into a production **Next.js + Tailwind** web app. Read it fully before writing code.

---

## 0. Goal

Recreate the **Deep Ocean** web experience as a Next.js app:

| Route | Design file (open in a browser to see the target) |
|---|---|
| `/` (marketing landing) | `Landing B.html` |
| `/jobs` (browse + filter) | `B Jobs.html` |
| `/jobs/[slug]` (job detail) | `B Job.html` |
| `/login` | `B Login.html` |
| `/signup` | `B Signup.html` |

The `A*` / `Landing A.html` files are an **alternate "Spotlight" direction — reference only, do not build** unless explicitly asked. Build the **B / Deep Ocean** screens.

## 1. These files are design references, not shippable code

The HTML/CSS/JS here are **prototypes that show the intended look, content, and behavior** — not code to paste in. Recreate them in the target codebase's real stack and conventions. The production app is **Next.js (App Router) + Tailwind CSS**, repo `zitch-systems/remotejobs44` (`app/layout.tsx`, `app/app/globals.css`, `tailwind.config.js`). If you are working in that repo, **map the tokens below onto its existing Tailwind theme** rather than copying raw CSS. If starting fresh, scaffold `create-next-app --ts --tailwind --app`.

**Fidelity: high.** Colors, type, spacing, radii, shadows, copy, and interactions are final — match them. Lift exact values from `colors_and_type.css` (tokens) and `components.css` (component styles); read `shared.js` for the data shape and render logic.

## 2. Source of truth + recent changes (read this)

The **HTML/CSS/JS files in this folder are canonical** and reflect the latest design. Where the older prose in `README.md` disagrees, **this file and the actual files win.** Recent changes already baked into the files:

- **Landing has NO filter-rail "listings" section.** The old "Find the one that fits — in seconds / N roles match" block was **removed**. The hero search button and trending chips link to `/jobs`. Do **not** rebuild that section on the landing; live filtering lives on `/jobs` only.
- **Job taxonomy is role-first.** `shared.js → JOBS` now centers on: **Virtual Assistant, Customer Service, Social Media Manager, Digital Marketing, Data Analyst, Product Manager, Software Engineer, Sales Manager** (plus Support/Marketing/Data variants). Use these as the seed roles. Categories used: Engineering, Marketing, Data & AI, Product, Sales, Support (+ Design/Finance/HR tints exist).
- **Positioning is worldwide** (not region-specific): "70,000+ live remote roles · 150+ countries hiring". Keep all copy worldwide.
- **Do not reference Greenhouse or Glassdoor** in any UI copy or seed data.
- **Mobile:** the hero header nav hides ≤880px, the "Log In" button hides ≤520px, and `overflow-x` is clamped — preserve this responsive behavior.
- **Hero micro-animations (Landing B):** the H1 word "remote" **flips in on a 3D X-axis** and the three hero stats **count up from 0**; both **replay together on a 5–8s loop** (paused when the tab is hidden or the hero is off-screen; the word also flips on hover/click). The header brand **icon** does a continuous gentle **3D nod** (forward/back), scoped to the `<svg>` glyph only — never the wordmark. All gated behind `prefers-reduced-motion`. (See §7.)
- **Company logos are full-colour now** — the marquee's old grayscale-until-hover treatment was removed and the source switched to Google's favicon service → DuckDuckGo → monogram (Simple Icons dropped). See §8.

## 3. Suggested structure (App Router)

```
app/
  layout.tsx            # <html> + font vars + ThemeProvider; imports globals.css
  globals.css           # Tailwind base + the CSS custom properties from colors_and_type.css
  page.tsx              # Landing (composes the section components below)
  jobs/page.tsx         # Browse: hero band + FilterRail + JobList + Pager (client filtering)
  jobs/[slug]/page.tsx  # Job detail: hero band + prose + sticky aside
  login/page.tsx
  signup/page.tsx
components/
  layout/Header.tsx  Footer.tsx  ThemeToggle.tsx
  landing/Hero.tsx  LogoMarquee.tsx  Differentiator.tsx  CategoryGrid.tsx
          FeaturedGrid.tsx  LiveWall.tsx  Mission.tsx  HowItWorks.tsx
          Capabilities.tsx  Testimonials.tsx  Faq.tsx  CtaBand.tsx
  jobs/FilterRail.tsx  JobRow.tsx  JobCard.tsx  SearchBar.tsx
  ui/Button.tsx  Pill.tsx  Stat.tsx  Badge.tsx
lib/
  jobs.ts            # Job/Company types + seed data (port shared.js JOBS/COMPANIES)
  logos.ts           # company logo URL + fallback chain (see §8)
  useCountUp.ts  useTheme.ts
public/fonts/        # Sora + DM Sans (copy the .ttf from ../fonts) OR use next/font
```

Use **Server Components** for static sections; add `"use client"` only where there is state/effects (theme toggle, count-up, live filtering, FAQ, password reveal, marquees).

## 4. Design tokens → Tailwind theme

All values live in **`colors_and_type.css`** as CSS custom properties — copy that variable block into `globals.css` under `:root` and `[data-theme="dark"]` (every token has a dark value), then reference via Tailwind `theme.extend`. Key values:

- **Brand "Deep Ocean" blue:** `600 #2563eb` (primary action/links/focus), `700 #1d4ed8` (hover/heavy), `800 #1e3a5f`, `900 #0f1e38`, `950 #060e1f`; scale `50 #eff6ff … 500 #3b82f6`. Dark-hero gradient `#0c1d3a → #0a1628 → #060e1f`.
- **Accent "Sunrise orange":** `--accent #f97316`, `--accent-light #fbbf46`, `--accent-dark #d48a0a`.
- **Surfaces (light → dark):** bg-app `#f8faff→#0a1628`, bg-section `#f1f5f9→#0f1e38`, bg-card `#ffffff→#111c35`; borders `#e8edf5 / #e2e8f0 / #f1f5f9`; text fg-1 `#0f172a→#e2e8f4` … fg-4 `#94a3b8`.
- **Semantic:** success `#1ea05e`, warning `#f59e0b`, danger `#ef4444`, info = brand-600.
- **Type:** display **Sora** (`--font-display`, H1–H5/buttons/numbers, 700/800), body **DM Sans** (`--font-body`), mono = system. Ramp (px): 10·11·13·15·17·20·24·30·38·50·64. LH tight 1.05 / snug 1.15 / normal 1.5. Tracking tight −0.02em.
- **Radii (px):** 4·6·10·16·24·32·pill 9999. **Shadows:** blue-tinted, e.g. md `0 4px 20px rgba(37,99,235,.16)`, xl `0 16px 56px rgba(37,99,235,.22)`. **Spacing:** 4px base. **Container:** max 1440, header 68.
- **Motion:** ease-spring `cubic-bezier(.34,1.56,.64,1)`; durations 150/200/300ms. Honor `prefers-reduced-motion`.

Fonts: prefer `next/font/local` pointing at `public/fonts/Sora-VariableFont_wght.ttf` and `DMSans-VariableFont_opsz_wght.ttf` (also on Google Fonts). Expose as `--font-display` / `--font-body`.

## 5. Screen notes

**Landing (`/`)** — section order controls the light/dark band rhythm. Top→bottom: **Hero** (dark, full-bleed photo `assets/hero-videocall-sm.jpg` under a directional navy scrim; left = eyebrow pill + H1 "The world's *remote* jobs. One search. Apply from anywhere." + lede + white search bar → `/jobs` + trending chips → `/jobs` + 3 stats `70k+ / 150+ / 10+` that count up — the H1 word *remote* flips in 3D and both re-run on a 5–8s loop (see §7); right = a "browser" preview window whose job feed auto-scrolls + a floating "Hired remotely this week" photo card) → **Company marquee** (two rows, opposite directions) → **Differentiator** "Three checks every listing passes" (Verified / Transparent / Fast, each with a mini UI mock) → **Category grid** (8 tiles w/ open-role counts) → **Featured** (`.fcard` rich cards) → **Live market wall** (dark; 4 columns streaming at different speeds, pause on hover, reduced-motion safe) → **Mission** → **How it works** (3 steps; price pills Day Pass $3 / Pro $19/mo) → **Capabilities** (6 tiles) → **Testimonials** (3 quotes + 5 stars) → **FAQ** (`<details>`) → **CTA band** (dark) → **Footer** (4-col + social + bottom bar).

**Jobs (`/jobs`)** — dark hero band (photo `assets/ig-duo-laptops.jpg` + scrim, breadcrumb, H1 "Search 70,000+ remote roles", white search bar, stat row) + results: sticky **FilterRail** (Category / Region [Worldwide / Remote-first / EMEA] / Type) + toolbar ("Showing N of 70,000+", Sort) + JobList + numbered pager. **Search/filter is live and client-side** here.

**Job detail (`/jobs/[slug]`)** — dark hero band (photo `assets/ig-focused-desk.jpg`), company logo in white tile, role H1, meta chips, apply/save/share row; body = 2-col prose article + sticky aside (salary card + apply CTA, company card, "Similar roles" from data).

**Login / Signup** — split screen (collapses < 880px, aside hides on mobile). Left = dark ocean brand panel over a photo+scrim with benefit checks + social proof. Right = theme toggle, Google + GitHub buttons, OR divider, icon inputs with focus ring, password show/hide. Signup adds Full name + Terms checkbox; **signup scrim is intentionally darker (0.90/0.93/0.96 alphas)** because its photo is brighter — don't lighten it. Submitting either → `/jobs` (placeholder; wire to real auth).

## 6. Data layer

Port `shared.js` to typed `lib/jobs.ts`:
```ts
type Job = { title:string; company:string; cat:string; region:string;
             pay:string; type:string; age:string; featured:boolean };
type Company = string; // marquee names
```
`JOBS` (seed roles, §2) drives the landing feed/featured/live-wall, the `/jobs` list, and "similar roles". `COMPANIES` (50 names) drives the marquee. `CAT_TINT` maps category → `[bgHex, fgHex]` for tag pills. Replace seed arrays with real API calls (`/api/jobs?query=&category=&region=&type=&page=`) returning the same shape; counts come from the server.

## 7. Interactions & behavior

- **Theme** toggle: `data-theme="dark"` on `<html>`, persisted to `localStorage` (`rj44-theme-b`). All tokens have dark values.
- **Count-up** hero stats: 0→target, cubic ease-out (~1.7s). On Landing B they play on entrance and then **re-run on a 5–8s loop** alongside the headline flip (paused when `document.hidden` or the hero is scrolled out of view). Skip entirely under reduced-motion (show final values). (`useCountUp`.)
- **Headline flip** (Landing B hero): the H1 `<em>` "remote" flips around the X-axis (`rotateX(-92°)→0`, ~0.9s) via a toggled `.flip-go` class (remove → reflow → re-add to replay); fires on entrance, on the 5–8s loop, and on hover/click. Reduced-motion shows it static.
- **Logo 3D nod** (Landing B header): the brand `<svg>` icon continuously tips forward/back (`rotateX ±34°` with an in-transform `perspective(320px)`, ~4s ease-in-out loop), scoped to the icon glyph **only** — the wordmark never transforms. Honor reduced-motion.
- **Live filter** on `/jobs`: typing filters rows by title/company/category and updates the visible count; filter-rail checkboxes toggle an active state.
- **Marquees / live wall:** CSS keyframe translate on a duplicated track; pause on hover; `animation:none` under reduced-motion.
- **Hero entrance:** staggered fade-up — make the **final state the base style** and only animate when live (the prototype gates it behind a JS-added attribute + `prefers-reduced-motion: no-preference`) so SSR/print/reduced-motion never render an invisible hero.
- **FAQ** native `<details>/<summary>` (+ rotates to ×). **Password reveal** toggles input type.
- **Responsive:** hero/listing grids → 1 col < 960px; auth → 1 col < 880px; hero header nav hidden < 880px; "Log In" hidden < 520px; live wall 2 cols < 960px, 1 col < 520px; floating hero photo hidden < 520px. Clamp `overflow-x`.

## 8. Company logos

Marks are **full-colour** (the old grayscale-until-hover treatment is gone) and fetched at render with a fallback chain: **Google favicon** `https://www.google.com/s2/favicons?domain=<domain>&sz=128` → **DuckDuckGo** `https://icons.duckduckgo.com/ip3/<domain>.ico` → tinted **monogram**. `BRAND_DOMAIN` is in `shared.js`; each `<img>` carries a pipe-delimited `data-fallback` list and `brandImgFail()` walks it one source at a time. Marks render ~34px (38px on a white tile in dark mode so any-colour logo stays legible). These services return the brand's square colour app-mark; for wordmark logos or guaranteed availability, self-host. (Monochrome **Simple Icons** was the old primary source — dropped because the brief is colour.) **For production:** self-host approved partner logos or use a licensed logo API and confirm usage rights — do not hot-link these services at scale.

## 9. Assets

In `assets/` (JPEGs, web-downscaled): `hero-videocall-sm.jpg` (landing hero + login panel), `ig-duo-laptops.jpg` (jobs hero), `ig-focused-desk.jpg` (detail hero), `ig-high-five.jpg` (landing floating card + signup panel), `people-4-portrait.jpg` / `ad-blazer-man.jpg` / `ad-coffee-woman.jpg` (portraits). Icons are inline **Feather-style** 2px stroke SVGs — map to Lucide. Replace stock photos with licensed/owned imagery before shipping.

## 10. Build order for Claude Code

1. Scaffold tokens + fonts: copy the `colors_and_type.css` variables into `globals.css`, wire Tailwind `theme.extend`, set up the two fonts, add the `ThemeProvider` + `<ThemeToggle>`.
2. Build shared `Header`, `Footer`, `Button`, `Pill`, `Badge`, `JobRow`, `JobCard`, `SearchBar`; add `lib/jobs.ts` + `lib/logos.ts`.
3. Landing `/` section-by-section (§5), Server Components + small client islands for count-up/marquee/FAQ.
4. `/jobs` with client-side filter + pager; then `/jobs/[slug]`.
5. `/login` + `/signup` (split layout, validation, password reveal); submit → `/jobs`.
6. Pass: responsive (§7), `prefers-reduced-motion`, a11y (labels, focus-visible, alt text, `<details>` semantics), Lighthouse.

## 11. Definition of done

Each route visually matches its HTML reference at desktop + mobile; light & dark both correct; theme persists; count-up / marquees / live filter / FAQ / password reveal work; reduced-motion shows final states; no console errors; copy is worldwide and contains no Greenhouse/Glassdoor references. Seed data is swappable for a real API without changing component props.
